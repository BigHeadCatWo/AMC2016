package com.alibaba.middleware.race.judge;

/**
 * Created by g on 2016/6/7.
 */
public enum MsgType {
    TaobaoOrderMsg,TmallOrderMsg,PaymentMsg;
}
