#!/bin/bash

jstorm jar preliminary.demo-1.0-SNAPSHOT.jar com.alibaba.middleware.race.jstorm.RaceTopology
